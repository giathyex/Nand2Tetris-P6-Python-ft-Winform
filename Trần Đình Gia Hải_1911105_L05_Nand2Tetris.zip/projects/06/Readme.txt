A Winform C++ GUI for a Python assembler for HACK machine

How to use:
- Make sure N2T.exe and Assembler.exe is in the same folder
- Open N2T.exe, choose the .ASM file, then click on Convert to machine code
- The new .HACK will be put in the same folder as the .ASM file

You can view the GUI source code at:
https://github.com/giathyex/Nand2Tetris-P6-Python-ft-Winform