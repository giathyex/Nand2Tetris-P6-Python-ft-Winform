A Winform C++ GUI for a Python assembler for HACK machine

The main source code of assembler is in SourceCode folder:
- The main source code of the Winform GUI is in GUI folder
- The main source code of the assembler is in PythonAssembler

How to use:
- Make sure N2T.exe and Assembler.exe is in the same folder
- Open N2T.exe, choose the .ASM file, then click on Convert to machine code
- The new .HACK will be put in the same folder as the .ASM file

https://github.com/giathyex/Nand2Tetris-P6-Python-ft-Winform